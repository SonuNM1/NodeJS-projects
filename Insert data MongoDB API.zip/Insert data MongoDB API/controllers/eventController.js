const Event = require('../model/eventModel') ; 
var eventController = {}

// creating a new event 

const createEvent = async (req, res) => {
    try{
        const event = new Event(req.body) ; 
        await event.save() ; 
        res.status(201).send(event) ; 
    } catch(err) {
        res.status(400).send(err);
    }
};


eventController.createEvent = createEvent;
module.exports = eventController ; 