const File = require('../models/file')

var routeController = {}

const addFile = (req, res) => {
    res.render('addFile');
}

// save the records (employeeName, fileName) into the database

const saveRecord = async (req, res) => {
    console.log(req.body)
    const { fileName, employeeName } = req.body;
    try {
        const file = new File({ fileName, employeeName });
        await file.save();
        res.redirect('displayInfo');
    } catch (err) {
        console.error('Saving the file', err);
        res.status(500).send('Error saving file');
    }
}

// display the files distributed to employee(id)

const displayByEmployee = async (req, res) => {
    const { name } = req.params;
    try {
        const files = await File.find({ employeeName: name });
        res.render('filesByEmployee', { files });
    } catch (err) {
        console.error('Error fetching files by employee name: ', err)
        res.status(500).send('Error fetching files');
    }
}


// display the details of file and corresponding employee

const displayAllData = async (req, res)=> {
    try{
        const files = await File.find() ; 
        res.render('display', {files}) ; 
    } catch (error) {
        console.error('Error retrieving files: ', error) ; 
        res.status(500).send('Internal Server Error') ; 
    }
} ; 


routeController.displayAllData = displayAllData
routeController.displayByEmployee = displayByEmployee
routeController.saveRecord = saveRecord
routeController.addFile = addFile

module.exports = routeController