const express = require('express') ; 
const mongoose = require('mongoose') ; 
const path = require('path') ; 
const hbs = require('hbs') ; 
const collection = require("./src/mongodb")
const templatePath = path.join(__dirname , './templates') 


const app = express() ; 

app.use(express.json()); 
app.set("view engine", "hbs") ; 
app.set("views", templatePath)
app.use(express.urlencoded({extended: false}))


app.get("/", (req, res)=>{
    res.render("login")
})

app.get("/signup", (req, res)=>{
    res.render("signup")
})

app.post("/signup", async (req, res)=>{
    const data = {
        name: req.body.name , 
        password: req.body.password
    }
    await collection.insertMany([data])

    res.render("home")
})

app.post("/login", async (req, res)=>{
   try{
        const check = await collection.findOne({name: req.body.name})

        if(check.password === req.body.password){
            res.render("home")
        }
        else{
            res.send("Wrong password")
        }

   }
   catch{
    res.send("wrong details")
   }
})

app.listen(4000, ()=>{
    console.log("Port connected") ; 
}) ; 